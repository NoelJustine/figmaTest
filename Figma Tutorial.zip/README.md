
  # Figma Tutorial

  This is a code bundle for Figma Tutorial. The original project is available at https://www.figma.com/design/Ez3eeJFZN6dlgl3VwPqHBK/Figma-Tutorial.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  