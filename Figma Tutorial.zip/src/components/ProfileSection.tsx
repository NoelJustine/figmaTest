import { motion } from "motion/react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Github, 
  Linkedin, 
  Mail, 
  MapPin, 
  Calendar,
  Code,
  Palette,
  Brain,
  Coffee
} from "lucide-react";

export function ProfileSection() {
  const skills = [
    { name: "JavaScript", icon: "🟨", level: 90 },
    { name: "React", icon: "⚛️", level: 85 },
    { name: "TypeScript", icon: "🔷", level: 80 },
    { name: "Node.js", icon: "🟢", level: 75 },
    { name: "Python", icon: "🐍", level: 85 },
    { name: "UI/UX Design", icon: "🎨", level: 70 },
  ];

  const interests = [
    { icon: Code, label: "Full Stack Development", color: "bg-blue-100 text-blue-700" },
    { icon: Palette, label: "UI/UX Design", color: "bg-purple-100 text-purple-700" },
    { icon: Brain, label: "Machine Learning", color: "bg-green-100 text-green-700" },
    { icon: Coffee, label: "Open Source", color: "bg-orange-100 text-orange-700" },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center py-20">
      {/* Background butterfly image */}
      <div className="absolute inset-0 opacity-10">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1650627851849-f81e6853b093?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGJ1dHRlcmZseSUyMG5hdHVyZXxlbnwxfHx8fDE3NTkzNjM2MTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Butterfly background"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container mx-auto px-4 z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Profile Card */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Card className="backdrop-blur-sm bg-white/80 border-2 border-purple-200 shadow-2xl">
              <CardContent className="p-8">
                {/* Avatar and Basic Info */}
                <div className="text-center mb-6">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
                    className="mb-4"
                  >
                    <Avatar className="w-32 h-32 mx-auto border-4 border-gradient-to-r from-purple-400 to-pink-400">
                      <AvatarImage src="/placeholder-avatar.jpg" />
                      <AvatarFallback className="text-2xl bg-gradient-to-br from-purple-400 to-pink-400 text-white">
                        👩‍💻
                      </AvatarFallback>
                    </Avatar>
                  </motion.div>
                  
                  <motion.h1 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2"
                  >
                    Your Name
                  </motion.h1>
                  
                  <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                    className="text-gray-600 text-lg mb-4"
                  >
                    Full Stack Developer & UI/UX Designer
                  </motion.p>

                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 }}
                    className="flex items-center justify-center gap-4 text-sm text-gray-500 mb-6"
                  >
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>Your City, Country</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>Available for projects</span>
                    </div>
                  </motion.div>

                  {/* Social Links */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 }}
                    className="flex justify-center gap-3 mb-6"
                  >
                    <Button variant="outline" size="sm" className="hover:bg-purple-50">
                      <Github className="w-4 h-4 mr-2" />
                      GitHub
                    </Button>
                    <Button variant="outline" size="sm" className="hover:bg-blue-50">
                      <Linkedin className="w-4 h-4 mr-2" />
                      LinkedIn
                    </Button>
                    <Button variant="outline" size="sm" className="hover:bg-green-50">
                      <Mail className="w-4 h-4 mr-2" />
                      Email
                    </Button>
                  </motion.div>
                </div>

                {/* Bio */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 }}
                  className="mb-6"
                >
                  <h3 className="font-semibold text-gray-800 mb-3">About Me</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Passionate developer with a love for creating beautiful, functional applications. 
                    I enjoy transforming ideas into reality through code and design, much like how a 
                    caterpillar transforms into a butterfly. Always learning, always growing.
                  </p>
                </motion.div>

                {/* Interests */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.0 }}
                >
                  <h3 className="font-semibold text-gray-800 mb-3">Interests</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {interests.map((interest, index) => (
                      <div 
                        key={index}
                        className={`flex items-center gap-2 p-2 rounded-lg ${interest.color} text-sm`}
                      >
                        <interest.icon className="w-4 h-4" />
                        <span>{interest.label}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Skills Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-6"
          >
            <div className="text-center lg:text-left">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                Skills & Technologies
              </h2>
              <p className="text-gray-600 mb-8">
                Like a butterfly's wings, my skills span across multiple domains, 
                creating beautiful and functional digital experiences.
              </p>
            </div>

            <div className="space-y-4">
              {skills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.2 + index * 0.1 }}
                  className="backdrop-blur-sm bg-white/60 rounded-lg p-4 border border-purple-200"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{skill.icon}</span>
                      <span className="font-medium text-gray-800">{skill.name}</span>
                    </div>
                    <span className="text-sm text-gray-600">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${skill.level}%` }}
                      transition={{ delay: 1.5 + index * 0.1, duration: 0.8 }}
                      className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full"
                    />
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Quote */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 2.0 }}
              className="text-center lg:text-left mt-8"
            >
              <blockquote className="text-lg italic text-gray-600 border-l-4 border-purple-400 pl-4">
                "Just as a butterfly emerges transformed, every project is an opportunity 
                to grow and create something beautiful."
              </blockquote>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}