import { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Play, RotateCcw, Trophy, Flame } from 'lucide-react';

interface Obstacle {
  id: number;
  x: number;
  topHeight: number;
  bottomHeight: number;
  passed: boolean;
}

interface GameState {
  isPlaying: boolean;
  isGameOver: boolean;
  score: number;
  highScore: number;
  dragonY: number;
  dragonVelocity: number;
  obstacles: Obstacle[];
  lastObstacleId: number;
}

const GAME_HEIGHT = 600;
const GAME_WIDTH = 800;
const DRAGON_SIZE = 60;
const OBSTACLE_WIDTH = 80;
const OBSTACLE_GAP = 200;
const GRAVITY = 0.6;
const JUMP_FORCE = -12;
const OBSTACLE_SPEED = 3;
const SPAWN_RATE = 120; // frames between obstacles

export function DragonGame() {
  const gameRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>();
  const frameCountRef = useRef(0);

  const [gameState, setGameState] = useState<GameState>({
    isPlaying: false,
    isGameOver: false,
    score: 0,
    highScore: parseInt(localStorage.getItem('dragonHighScore') || '0'),
    dragonY: GAME_HEIGHT / 2,
    dragonVelocity: 0,
    obstacles: [],
    lastObstacleId: 0,
  });

  const resetGame = useCallback(() => {
    setGameState(prev => ({
      ...prev,
      isPlaying: false,
      isGameOver: false,
      score: 0,
      dragonY: GAME_HEIGHT / 2,
      dragonVelocity: 0,
      obstacles: [],
      lastObstacleId: 0,
    }));
    frameCountRef.current = 0;
  }, []);

  const startGame = useCallback(() => {
    resetGame();
    setGameState(prev => ({ ...prev, isPlaying: true }));
  }, [resetGame]);

  const jump = useCallback(() => {
    if (gameState.isGameOver) return;
    
    if (!gameState.isPlaying) {
      startGame();
      return;
    }

    setGameState(prev => ({
      ...prev,
      dragonVelocity: JUMP_FORCE,
    }));
  }, [gameState.isGameOver, gameState.isPlaying, startGame]);

  const createObstacle = useCallback((id: number): Obstacle => {
    const minHeight = 50;
    const maxHeight = GAME_HEIGHT - OBSTACLE_GAP - minHeight;
    const topHeight = Math.random() * (maxHeight - minHeight) + minHeight;
    
    return {
      id,
      x: GAME_WIDTH,
      topHeight,
      bottomHeight: GAME_HEIGHT - topHeight - OBSTACLE_GAP,
      passed: false,
    };
  }, []);

  const checkCollision = useCallback((dragonY: number, obstacles: Obstacle[]): boolean => {
    // Check ground and ceiling
    if (dragonY <= 0 || dragonY >= GAME_HEIGHT - DRAGON_SIZE) {
      return true;
    }

    // Check obstacles
    const dragonLeft = 100;
    const dragonRight = dragonLeft + DRAGON_SIZE;
    const dragonTop = dragonY;
    const dragonBottom = dragonY + DRAGON_SIZE;

    for (const obstacle of obstacles) {
      const obstacleLeft = obstacle.x;
      const obstacleRight = obstacle.x + OBSTACLE_WIDTH;

      if (dragonRight > obstacleLeft && dragonLeft < obstacleRight) {
        // Check collision with top obstacle
        if (dragonTop < obstacle.topHeight) {
          return true;
        }
        // Check collision with bottom obstacle
        if (dragonBottom > GAME_HEIGHT - obstacle.bottomHeight) {
          return true;
        }
      }
    }

    return false;
  }, []);

  const gameLoop = useCallback(() => {
    setGameState(prev => {
      if (!prev.isPlaying || prev.isGameOver) {
        return prev;
      }

      frameCountRef.current += 1;

      // Update dragon physics
      const newVelocity = prev.dragonVelocity + GRAVITY;
      const newDragonY = Math.max(0, Math.min(GAME_HEIGHT - DRAGON_SIZE, prev.dragonY + newVelocity));

      // Update obstacles
      let newObstacles = prev.obstacles.map(obstacle => ({
        ...obstacle,
        x: obstacle.x - OBSTACLE_SPEED,
      })).filter(obstacle => obstacle.x > -OBSTACLE_WIDTH);

      // Add new obstacles
      if (frameCountRef.current % SPAWN_RATE === 0) {
        newObstacles.push(createObstacle(prev.lastObstacleId + 1));
      }

      // Check for score updates
      let newScore = prev.score;
      newObstacles = newObstacles.map(obstacle => {
        if (!obstacle.passed && obstacle.x + OBSTACLE_WIDTH < 100) {
          newScore += 1;
          return { ...obstacle, passed: true };
        }
        return obstacle;
      });

      // Check collisions
      const collision = checkCollision(newDragonY, newObstacles);
      
      if (collision) {
        const newHighScore = Math.max(prev.highScore, newScore);
        localStorage.setItem('dragonHighScore', newHighScore.toString());
        
        return {
          ...prev,
          isPlaying: false,
          isGameOver: true,
          highScore: newHighScore,
          score: newScore,
        };
      }

      return {
        ...prev,
        dragonY: newDragonY,
        dragonVelocity: newVelocity,
        obstacles: newObstacles,
        lastObstacleId: frameCountRef.current % SPAWN_RATE === 0 ? prev.lastObstacleId + 1 : prev.lastObstacleId,
        score: newScore,
      };
    });

    animationRef.current = requestAnimationFrame(gameLoop);
  }, [createObstacle, checkCollision]);

  useEffect(() => {
    if (gameState.isPlaying) {
      animationRef.current = requestAnimationFrame(gameLoop);
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [gameState.isPlaying, gameLoop]);

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.code === 'Space') {
        event.preventDefault();
        jump();
      }
    };

    const handleClick = () => {
      jump();
    };

    document.addEventListener('keydown', handleKeyPress);
    if (gameRef.current) {
      gameRef.current.addEventListener('click', handleClick);
    }

    return () => {
      document.removeEventListener('keydown', handleKeyPress);
      if (gameRef.current) {
        gameRef.current.removeEventListener('click', handleClick);
      }
    };
  }, [jump]);

  const dragonRotation = Math.max(-30, Math.min(30, gameState.dragonVelocity * 3));

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-sky-400 via-sky-300 to-green-200 p-4">
      <div className="mb-4 flex items-center gap-4">
        <Badge variant="secondary" className="text-lg px-4 py-2">
          <Trophy className="w-4 h-4 mr-2" />
          Score: {gameState.score}
        </Badge>
        <Badge variant="outline" className="text-lg px-4 py-2">
          <Flame className="w-4 h-4 mr-2" />
          Best: {gameState.highScore}
        </Badge>
      </div>

      <div 
        ref={gameRef}
        className="relative bg-gradient-to-b from-blue-400 to-blue-600 rounded-lg shadow-2xl cursor-pointer overflow-hidden border-4 border-yellow-400"
        style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}
        onClick={jump}
      >
        {/* Background clouds */}
        <div className="absolute inset-0">
          <div className="absolute top-10 left-20 w-20 h-12 bg-white rounded-full opacity-80"></div>
          <div className="absolute top-32 left-60 w-16 h-10 bg-white rounded-full opacity-70"></div>
          <div className="absolute top-48 left-10 w-24 h-14 bg-white rounded-full opacity-75"></div>
          <div className="absolute top-80 right-20 w-18 h-11 bg-white rounded-full opacity-80"></div>
        </div>

        {/* Dragon */}
        <div
          className="absolute transition-transform duration-100 z-20"
          style={{
            left: 100 - DRAGON_SIZE / 2,
            top: gameState.dragonY,
            transform: `rotate(${dragonRotation}deg)`,
          }}
        >
          <div 
            className="relative"
            style={{ width: DRAGON_SIZE, height: DRAGON_SIZE }}
          >
            {/* Dragon body */}
            <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-red-700 rounded-full shadow-lg">
              {/* Dragon head */}
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-br from-red-400 to-red-600 rounded-full">
                {/* Eyes */}
                <div className="absolute top-1 left-1 w-2 h-2 bg-yellow-300 rounded-full"></div>
                <div className="absolute top-1 right-1 w-2 h-2 bg-yellow-300 rounded-full"></div>
              </div>
              {/* Wings */}
              <div className="absolute -top-4 left-2 w-12 h-8 bg-gradient-to-r from-orange-400 to-red-500 rounded-full transform -rotate-12 animate-pulse"></div>
              <div className="absolute top-4 left-2 w-12 h-8 bg-gradient-to-r from-orange-400 to-red-500 rounded-full transform rotate-12 animate-pulse"></div>
              {/* Tail */}
              <div className="absolute top-4 -left-6 w-8 h-4 bg-gradient-to-l from-red-600 to-red-800 rounded-full"></div>
              {/* Fire breath effect when jumping */}
              {gameState.dragonVelocity < -5 && (
                <div className="absolute -right-8 top-6 w-12 h-3">
                  <div className="w-full h-full bg-gradient-to-r from-red-500 via-orange-400 to-yellow-300 rounded-full animate-ping"></div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Obstacles */}
        {gameState.obstacles.map(obstacle => (
          <div key={obstacle.id}>
            {/* Top obstacle */}
            <div
              className="absolute bg-gradient-to-b from-gray-600 to-gray-800 border-4 border-gray-500 rounded-b-lg"
              style={{
                left: obstacle.x,
                top: 0,
                width: OBSTACLE_WIDTH,
                height: obstacle.topHeight,
              }}
            >
              <div className="absolute bottom-0 left-0 right-0 h-4 bg-green-600 rounded-b-lg"></div>
            </div>
            {/* Bottom obstacle */}
            <div
              className="absolute bg-gradient-to-t from-gray-600 to-gray-800 border-4 border-gray-500 rounded-t-lg"
              style={{
                left: obstacle.x,
                bottom: 0,
                width: OBSTACLE_WIDTH,
                height: obstacle.bottomHeight,
              }}
            >
              <div className="absolute top-0 left-0 right-0 h-4 bg-green-600 rounded-t-lg"></div>
            </div>
          </div>
        ))}

        {/* Start screen */}
        {!gameState.isPlaying && !gameState.isGameOver && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-30">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-3xl text-red-600 flex items-center justify-center gap-2">
                  🐉 Dragon Flight
                </CardTitle>
                <p className="text-gray-600">Guide the dragon through the mystical mountains!</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-500">
                  Click or press SPACEBAR to flap wings
                </p>
                <Button onClick={startGame} size="lg" className="bg-red-600 hover:bg-red-700">
                  <Play className="w-4 h-4 mr-2" />
                  Start Adventure
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Game over screen */}
        {gameState.isGameOver && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-30">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-2xl text-red-600">Game Over!</CardTitle>
                <p className="text-gray-600">Your dragon has fallen</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-lg">Score: {gameState.score}</p>
                  {gameState.score === gameState.highScore && gameState.score > 0 && (
                    <Badge className="bg-yellow-500 text-yellow-900">
                      🎉 New High Score!
                    </Badge>
                  )}
                  <p className="text-sm text-gray-500">Best: {gameState.highScore}</p>
                </div>
                <div className="flex gap-2 justify-center">
                  <Button onClick={startGame} className="bg-red-600 hover:bg-red-700">
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Try Again
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Instructions */}
        {gameState.isPlaying && (
          <div className="absolute top-4 left-4 text-white text-sm opacity-75 z-10">
            Click or press SPACEBAR to fly
          </div>
        )}
      </div>

      <div className="mt-4 text-center text-sm text-gray-600 max-w-md">
        <p>Navigate your dragon through the mountain passages. Each gap you pass through increases your score!</p>
      </div>
    </div>
  );
}