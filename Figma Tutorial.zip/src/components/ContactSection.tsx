import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { 
  Mail, 
  Github, 
  Linkedin, 
  Twitter, 
  MapPin, 
  Phone,
  Send,
  MessageCircle,
  Calendar,
  Heart
} from "lucide-react";

export function ContactSection() {
  const contactMethods = [
    {
      icon: Mail,
      label: "Email",
      value: "your.email@example.com",
      href: "mailto:your.email@example.com",
      color: "bg-red-100 text-red-700"
    },
    {
      icon: Github,
      label: "GitHub",
      value: "github.com/yourusername",
      href: "https://github.com/yourusername",
      color: "bg-gray-100 text-gray-700"
    },
    {
      icon: Linkedin,
      label: "LinkedIn",
      value: "linkedin.com/in/yourprofile",
      href: "https://linkedin.com/in/yourprofile",
      color: "bg-blue-100 text-blue-700"
    },
    {
      icon: Twitter,
      label: "Twitter",
      value: "@yourusername",
      href: "https://twitter.com/yourusername",
      color: "bg-sky-100 text-sky-700"
    }
  ];

  const quickStats = [
    { label: "Projects Completed", value: "12+", icon: "🚀" },
    { label: "Lines of Code", value: "10K+", icon: "💻" },
    { label: "Coffee Consumed", value: "∞", icon: "☕" },
    { label: "Bugs Fixed", value: "99.9%", icon: "🐛" }
  ];

  return (
    <section className="py-20 relative bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            Let's Connect & Create Together
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Like butterflies drawn to beautiful flowers, I'm always excited to connect with 
            fellow developers, designers, and dreamers. Let's build something amazing!
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-2"
          >
            <Card className="backdrop-blur-sm bg-white/80 border-2 border-purple-200 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <MessageCircle className="w-6 h-6 text-purple-600" />
                  Send Me a Message
                </CardTitle>
                <p className="text-gray-600">
                  Have a project in mind? Want to collaborate? Just want to say hi? 
                  I'd love to hear from you!
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Name
                    </label>
                    <Input 
                      placeholder="Your name" 
                      className="border-purple-200 focus:border-purple-400"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Email
                    </label>
                    <Input 
                      type="email" 
                      placeholder="your.email@example.com" 
                      className="border-purple-200 focus:border-purple-400"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Subject
                  </label>
                  <Input 
                    placeholder="What's this about?" 
                    className="border-purple-200 focus:border-purple-400"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Message
                  </label>
                  <Textarea 
                    placeholder="Tell me about your project, idea, or just say hello!" 
                    className="min-h-32 border-purple-200 focus:border-purple-400"
                  />
                </div>
                
                <Button 
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  size="lg"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  I typically respond within 24 hours. Looking forward to connecting!
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Contact Info & Stats */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            {/* Contact Methods */}
            <Card className="backdrop-blur-sm bg-white/80 border-2 border-purple-200 shadow-xl">
              <CardHeader>
                <CardTitle className="text-xl">Get In Touch</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {contactMethods.map((method, index) => (
                  <motion.a
                    key={method.label}
                    href={method.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-purple-50 transition-colors group"
                  >
                    <div className={`p-2 rounded-lg ${method.color}`}>
                      <method.icon className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800 group-hover:text-purple-600 transition-colors">
                        {method.label}
                      </p>
                      <p className="text-sm text-gray-600">{method.value}</p>
                    </div>
                  </motion.a>
                ))}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="backdrop-blur-sm bg-white/80 border-2 border-purple-200 shadow-xl">
              <CardHeader>
                <CardTitle className="text-xl">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {quickStats.map((stat, index) => (
                    <motion.div
                      key={stat.label}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="text-center p-3 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg"
                    >
                      <div className="text-2xl mb-1">{stat.icon}</div>
                      <div className="font-bold text-purple-600">{stat.value}</div>
                      <div className="text-xs text-gray-600">{stat.label}</div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Availability */}
            <Card className="backdrop-blur-sm bg-white/80 border-2 border-purple-200 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="font-medium text-gray-800">Available for Projects</span>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Currently open to new opportunities and collaborations!
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full border-purple-200 hover:bg-purple-50"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule a Call
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mt-16"
        >
          <div className="flex items-center justify-center gap-2 text-gray-600 mb-4">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-500 animate-pulse" />
            <span>and lots of</span>
            <span>☕</span>
          </div>
          <div className="flex justify-center gap-4 text-sm text-gray-500">
            <span>© 2024 Your Name</span>
            <span>•</span>
            <span>Portfolio v2.0</span>
            <span>•</span>
            <span>Butterfly Theme 🦋</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}