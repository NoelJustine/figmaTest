import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { CheckCircle2, Circle } from "lucide-react";

interface TutorialStepProps {
  step: number;
  title: string;
  description: string;
  content: string;
  tips?: string[];
  isCompleted?: boolean;
  difficulty?: "Beginner" | "Intermediate" | "Advanced";
}

export function TutorialStep({ 
  step, 
  title, 
  description, 
  content, 
  tips = [], 
  isCompleted = false,
  difficulty = "Beginner"
}: TutorialStepProps) {
  const difficultyColors = {
    Beginner: "bg-green-100 text-green-800",
    Intermediate: "bg-yellow-100 text-yellow-800",
    Advanced: "bg-red-100 text-red-800"
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isCompleted ? (
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            ) : (
              <Circle className="w-6 h-6 text-gray-400" />
            )}
            <div>
              <CardTitle className="flex items-center gap-2">
                Step {step}: {title}
                <Badge className={difficultyColors[difficulty]}>{difficulty}</Badge>
              </CardTitle>
              <CardDescription>{description}</CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="prose max-w-none">
          <p>{content}</p>
          {tips.length > 0 && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <h4 className="text-sm font-medium text-blue-900 mb-2">💡 Pro Tips:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                {tips.map((tip, index) => (
                  <li key={index}>• {tip}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}