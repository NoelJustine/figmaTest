import { motion } from "motion/react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  ExternalLink, 
  Github, 
  Code, 
  Palette, 
  Database, 
  Smartphone,
  Globe,
  Brain,
  Gamepad2,
  BookOpen
} from "lucide-react";

interface Project {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  technologies: string[];
  category: string;
  icon: any;
  image?: string;
  githubUrl?: string;
  demoUrl?: string;
  status: "completed" | "in-progress" | "planning";
}

export function ProjectsSection() {
  const projects: Project[] = [
    {
      id: "lab1",
      title: "Web Development Fundamentals",
      description: "HTML, CSS, and JavaScript basics with responsive design",
      longDescription: "A comprehensive exploration of web development fundamentals including semantic HTML structure, modern CSS techniques with Flexbox and Grid, and interactive JavaScript functionality.",
      technologies: ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
      category: "Web Development",
      icon: Code,
      image: "https://images.unsplash.com/photo-1569693799105-4eb645d89aea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ncmFtbWluZyUyMGNvZGUlMjBsYXB0b3B8ZW58MXx8fHwxNzU5MzEyNDcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      githubUrl: "#",
      demoUrl: "#",
      status: "completed"
    },
    {
      id: "lab2",
      title: "React Components Library",
      description: "Reusable React components with TypeScript and Storybook",
      longDescription: "Building a comprehensive component library using React and TypeScript, documented with Storybook for better component development and testing.",
      technologies: ["React", "TypeScript", "Storybook", "CSS Modules"],
      category: "Frontend",
      icon: Palette,
      githubUrl: "#",
      demoUrl: "#",
      status: "completed"
    },
    {
      id: "lab3",
      title: "API Integration Project",
      description: "Full-stack application with REST API and database integration",
      longDescription: "A full-stack web application demonstrating API development, database design, user authentication, and frontend-backend communication.",
      technologies: ["Node.js", "Express", "MongoDB", "React", "JWT"],
      category: "Full Stack",
      icon: Database,
      githubUrl: "#",
      demoUrl: "#",
      status: "completed"
    },
    {
      id: "lab4",
      title: "Mobile-First Design",
      description: "Progressive Web App with mobile-first approach",
      longDescription: "Creating a progressive web application following mobile-first design principles with service workers, offline functionality, and responsive design.",
      technologies: ["PWA", "Service Workers", "CSS Grid", "JavaScript"],
      category: "Mobile",
      icon: Smartphone,
      githubUrl: "#",
      demoUrl: "#",
      status: "in-progress"
    },
    {
      id: "lab5",
      title: "Data Visualization Dashboard",
      description: "Interactive charts and graphs using D3.js and React",
      longDescription: "Building an interactive data visualization dashboard with real-time updates, multiple chart types, and responsive design for data analysis.",
      technologies: ["D3.js", "React", "Python", "FastAPI", "Chart.js"],
      category: "Data Science",
      icon: Brain,
      githubUrl: "#",
      demoUrl: "#",
      status: "in-progress"
    },
    {
      id: "lab6",
      title: "Game Development Project",
      description: "Browser-based game using Canvas API and game physics",
      longDescription: "Creating an interactive browser game with HTML5 Canvas, game physics, collision detection, and engaging gameplay mechanics.",
      technologies: ["Canvas API", "JavaScript", "Game Physics", "Audio API"],
      category: "Game Development",
      icon: Gamepad2,
      githubUrl: "#",
      demoUrl: "#",
      status: "planning"
    }
  ];

  const categories = [...new Set(projects.map(p => p.category))];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "in-progress": return "bg-yellow-100 text-yellow-800";
      case "planning": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed": return "✅ Completed";
      case "in-progress": return "🔄 In Progress";
      case "planning": return "📋 Planning";
      default: return status;
    }
  };

  return (
    <section className="py-20 relative">
      {/* Background butterfly wing pattern */}
      <div className="absolute inset-0 opacity-5">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1744077064156-83ba0ed5d0b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hcmNoJTIwYnV0dGVyZmx5JTIwd2luZ3N8ZW58MXx8fHwxNzU5MzYzNjIyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Butterfly wings pattern"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            Laboratory Tasks & Projects
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Each project represents a stage of growth in my development journey, 
            like the metamorphosis of a butterfly - from concept to beautiful, functional reality.
          </p>
          
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mt-8">
            <Badge variant="outline" className="cursor-pointer hover:bg-purple-100">
              All Projects
            </Badge>
            {categories.map((category) => (
              <Badge 
                key={category}
                variant="outline" 
                className="cursor-pointer hover:bg-purple-100"
              >
                {category}
              </Badge>
            ))}
          </div>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="group"
            >
              <Card className="h-full backdrop-blur-sm bg-white/80 border-2 border-purple-100 hover:border-purple-300 transition-all duration-300 shadow-lg hover:shadow-xl">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-3 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg">
                      <project.icon className="w-6 h-6 text-purple-600" />
                    </div>
                    <Badge className={getStatusColor(project.status)}>
                      {getStatusText(project.status)}
                    </Badge>
                  </div>
                  
                  {project.image && (
                    <div className="aspect-video overflow-hidden rounded-lg mb-4">
                      <ImageWithFallback
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  
                  <CardTitle className="text-xl mb-2 group-hover:text-purple-600 transition-colors">
                    {project.title}
                  </CardTitle>
                  <CardDescription className="text-gray-600">
                    {project.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <p className="text-sm text-gray-600 mb-4 leading-relaxed">
                    {project.longDescription}
                  </p>
                  
                  {/* Technologies */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map((tech) => (
                      <Badge 
                        key={tech} 
                        variant="secondary"
                        className="text-xs bg-purple-50 text-purple-700"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    {project.githubUrl && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 hover:bg-purple-50"
                        asChild
                      >
                        <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                          <Github className="w-4 h-4 mr-2" />
                          Code
                        </a>
                      </Button>
                    )}
                    {project.demoUrl && (
                      <Button 
                        size="sm" 
                        className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                        asChild
                      >
                        <a href={project.demoUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Demo
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Learning Journey Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mt-20 text-center"
        >
          <Card className="backdrop-blur-sm bg-white/80 border-2 border-purple-200 p-8">
            <div className="flex items-center justify-center mb-4">
              <BookOpen className="w-8 h-8 text-purple-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-800">Learning Journey</h3>
            </div>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Like a butterfly's transformation, my journey through these laboratory tasks represents 
              continuous growth and evolution. Each project builds upon the last, creating a 
              comprehensive understanding of modern software development.
            </p>
            <div className="flex items-center justify-center gap-8 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span>{projects.filter(p => p.status === 'completed').length} Completed</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span>{projects.filter(p => p.status === 'in-progress').length} In Progress</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span>{projects.filter(p => p.status === 'planning').length} Planned</span>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}