import { useState, useEffect } from "react";
import { ButterflyAnimation } from "./components/ButterflyAnimation";
import { Navigation } from "./components/Navigation";
import { ProfileSection } from "./components/ProfileSection";
import { ProjectsSection } from "./components/ProjectsSection";
import { ContactSection } from "./components/ContactSection";

export default function App() {
  const [activeSection, setActiveSection] = useState("profile");

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["profile", "projects", "contact"];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;
          
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Animated butterfly background */}
      <ButterflyAnimation />
      
      {/* Navigation */}
      <Navigation 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
      />
      
      {/* Main Content */}
      <main className="relative z-10">
        {/* Profile Section */}
        <div id="profile">
          <ProfileSection />
        </div>
        
        {/* Projects Section */}
        <div id="projects">
          <ProjectsSection />
        </div>
        
        {/* Contact Section */}
        <div id="contact">
          <ContactSection />
        </div>
      </main>
    </div>
  );
}